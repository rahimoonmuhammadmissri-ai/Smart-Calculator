# SmartCalc — By Missri Rahimoon

A full-featured Android calculator app with three tabs:

## Features
1. **Calculator** — basic + scientific mode (sin, cos, tan, log, ln, √, power,
   parentheses, π, e, factorial, percentage). Tap "Sci" to reveal the
   scientific button panel.
2. **Currency Converter** — live exchange rates fetched from a free public API
   (no key required), supports USD, PKR, EUR, GBP, SAR, AED, INR and more.
   Requires internet; shows "Offline" if no connection.
3. **Unit Converter** — Length, Weight, and Temperature, fully offline.

Plus a **dark/light theme toggle** (sun/moon icon in the top bar) — the choice
is remembered next time you open the app.

## How to build & install
Same GitHub Actions flow as before:
1. Create a new GitHub repo (e.g. `SmartCalc`)
2. Upload this whole zip via "Add file → Upload files" — the workflow file
   is already included at `.github/workflows/build-apk.yml`
3. Check the "Actions" tab — a build will start automatically
4. Once it's green ✅, open that run and download the `SmartCalc-debug-apk`
   artifact
5. Extract it, install `app-debug.apk` on your phone (allow "unknown sources"
   if asked)

## Notes
- Currency rates need an internet connection at the time of conversion.
- All XML files are validated to avoid the earlier "malformed file" build
  error you ran into with AppTwin.
