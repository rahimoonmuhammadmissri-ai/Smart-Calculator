package com.missrirahimoon.smartcalc

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.missrirahimoon.smartcalc.ui.CalculatorFragment
import com.missrirahimoon.smartcalc.ui.CurrencyFragment
import com.missrirahimoon.smartcalc.ui.UnitsFragment

class MainActivity : AppCompatActivity() {

    private val prefsName = "smartcalc_prefs"
    private val themeKey = "dark_mode"

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedTheme()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, CalculatorFragment())
                .commit()
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.nav_calculator -> CalculatorFragment()
                R.id.nav_currency -> CurrencyFragment()
                R.id.nav_units -> UnitsFragment()
                else -> CalculatorFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        if (item.itemId == R.id.action_toggle_theme) {
            toggleTheme()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun applySavedTheme() {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val isDark = prefs.getBoolean(themeKey, false)
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun toggleTheme() {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val isDark = prefs.getBoolean(themeKey, false)
        prefs.edit().putBoolean(themeKey, !isDark).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (!isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        recreate()
    }
}
