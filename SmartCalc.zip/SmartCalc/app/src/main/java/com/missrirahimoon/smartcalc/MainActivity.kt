package com.missrirahimoon.smartcalc

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.missrirahimoon.smartcalc.ui.CalculatorFragment
import com.missrirahimoon.smartcalc.ui.CurrencyFragment
import com.missrirahimoon.smartcalc.ui.UnitsFragment

class MainActivity : AppCompatActivity() {

    private val prefsName = "smartcalc_prefs"
    private val themeKey = "dark_mode"

    private lateinit var bottomNav: BottomNavigationView
    private lateinit var toggleThumb: View
    private lateinit var toggleThumbIcon: ImageView
    private var calculatorFragment: CalculatorFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedTheme()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.statusBarColor = Color.TRANSPARENT

        bottomNav = findViewById(R.id.bottomNav)
        toggleThumb = findViewById(R.id.toggleThumb)
        toggleThumbIcon = findViewById(R.id.toggleThumbIcon)

        if (savedInstanceState == null) {
            val fragment = CalculatorFragment()
            calculatorFragment = fragment
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
        }

        syncToggleVisualState(animate = false)

        bottomNav.setOnItemSelectedListener { item ->
            val fragment = when (item.itemId) {
                R.id.nav_calculator -> CalculatorFragment().also { calculatorFragment = it }
                R.id.nav_currency -> CurrencyFragment()
                R.id.nav_units -> UnitsFragment()
                else -> CalculatorFragment().also { calculatorFragment = it }
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit()
            true
        }

        findViewById<ImageButton>(R.id.btnInfo).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        findViewById<FrameLayout>(R.id.dayNightToggle).setOnClickListener {
            toggleTheme()
        }

        findViewById<android.widget.Button>(R.id.btnSci).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_calculator
            calculatorFragment?.toggleSciPanel()
        }

        findViewById<android.widget.Button>(R.id.btnUnitsShortcut).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_units
        }

        findViewById<ImageButton>(R.id.btnCurrencyShortcut).setOnClickListener {
            bottomNav.selectedItemId = R.id.nav_currency
        }
    }

    /** Called by CalculatorFragment when the scientific panel is shown/hidden,
     *  so the screen can rotate into landscape for the extra button rows. */
    fun setScientificLandscape(enabled: Boolean) {
        requestedOrientation = if (enabled) {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun applySavedTheme() {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val isDark = prefs.getBoolean(themeKey, false)
        AppCompatDelegate.setDefaultNightMode(
            if (isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun toggleTheme() {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val isDark = prefs.getBoolean(themeKey, false)
        prefs.edit().putBoolean(themeKey, !isDark).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (!isDark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        recreate()
    }

    private fun syncToggleVisualState(animate: Boolean) {
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val isDark = prefs.getBoolean(themeKey, false)
        val track = findViewById<FrameLayout>(R.id.dayNightToggle)
        track.post {
            val endX = (track.width - toggleThumb.width - (3 * resources.displayMetrics.density)).let {
                if (it < 0) 0f else it
            }
            val targetX = if (isDark) endX else 0f
            if (animate) {
                toggleThumb.animate().translationX(targetX).setDuration(180).start()
                toggleThumbIcon.animate().translationX(targetX).setDuration(180).start()
            } else {
                toggleThumb.translationX = targetX
                toggleThumbIcon.translationX = targetX
            }
            toggleThumb.setBackgroundResource(
                if (isDark) R.drawable.bg_toggle_thumb_moon else R.drawable.bg_toggle_thumb_sun
            )
            toggleThumbIcon.setImageResource(
                if (isDark) R.drawable.ic_moon_filled else R.drawable.ic_sun_filled
            )
        }
    }
}
