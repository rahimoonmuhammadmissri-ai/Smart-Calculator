package com.missrirahimoon.smartcalc.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.missrirahimoon.smartcalc.R
import com.missrirahimoon.smartcalc.util.ExpressionEvaluator

class CalculatorFragment : Fragment(R.layout.fragment_calculator) {

    private var expression: String = ""
    private lateinit var tvExpression: TextView
    private lateinit var tvResult: TextView
    private lateinit var sciPanel: View

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvExpression = view.findViewById(R.id.tvExpression)
        tvResult = view.findViewById(R.id.tvResult)
        sciPanel = view.findViewById(R.id.sciPanel)

        // Digits & simple appends
        mapOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2", R.id.btn3 to "3",
            R.id.btn4 to "4", R.id.btn5 to "5", R.id.btn6 to "6", R.id.btn7 to "7",
            R.id.btn8 to "8", R.id.btn9 to "9", R.id.btnDot to ".",
            R.id.btnPlus to "+", R.id.btnMinus to "-", R.id.btnMultiply to "*",
            R.id.btnDivide to "/", R.id.btnPercent to "%",
            R.id.btnLParen to "(", R.id.btnRParen to ")",
            R.id.btnPi to "π", R.id.btnE to "e", R.id.btnFactorial to "!",
            R.id.btnPow to "^"
        ).forEach { (id, text) ->
            view.findViewById<Button>(id).setOnClickListener { append(text) }
        }

        // Functions that need an opening parenthesis
        mapOf(
            R.id.btnSin to "sin(", R.id.btnCos to "cos(", R.id.btnTan to "tan(",
            R.id.btnLog to "log(", R.id.btnLn to "ln(", R.id.btnSqrt to "sqrt("
        ).forEach { (id, text) ->
            view.findViewById<Button>(id).setOnClickListener { append(text) }
        }

        view.findViewById<Button>(R.id.btnClear).setOnClickListener {
            expression = ""
            updateDisplay(clearResult = true)
        }

        view.findViewById<Button>(R.id.btnBackspace).setOnClickListener {
            if (expression.isNotEmpty()) {
                expression = expression.dropLast(1)
                updateDisplay()
            }
        }

        view.findViewById<Button>(R.id.btnEquals).setOnClickListener {
            evaluateExpression()
        }

        view.findViewById<Button>(R.id.btnSciToggle).setOnClickListener {
            sciPanel.visibility = if (sciPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    private fun append(text: String) {
        expression += text
        updateDisplay()
    }

    private fun updateDisplay(clearResult: Boolean = false) {
        tvExpression.text = expression
        if (clearResult) {
            tvResult.text = "0"
            return
        }
        // Live preview of the result, but never crash the UI on partial/invalid input
        try {
            val value = ExpressionEvaluator.evaluate(expression)
            tvResult.text = formatResult(value)
        } catch (_: Exception) {
            // leave last valid result showing while the user is still typing
        }
    }

    private fun evaluateExpression() {
        try {
            val value = ExpressionEvaluator.evaluate(expression)
            tvResult.text = formatResult(value)
            expression = formatResult(value)
        } catch (e: Exception) {
            tvResult.text = "Error"
        }
    }

    private fun formatResult(value: Double): String {
        return if (value == value.toLong().toDouble()) {
            value.toLong().toString()
        } else {
            "%.6f".format(value).trimEnd('0').trimEnd('.')
        }
    }
}
