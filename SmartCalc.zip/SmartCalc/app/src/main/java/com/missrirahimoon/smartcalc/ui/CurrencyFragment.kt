package com.missrirahimoon.smartcalc.ui

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.missrirahimoon.smartcalc.R
import com.missrirahimoon.smartcalc.util.CurrencyApi
import kotlinx.coroutines.launch

class CurrencyFragment : Fragment(R.layout.fragment_currency) {

    private var lastRates: Map<String, Double>? = null
    private var lastBase: String = "USD"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spinnerFrom = view.findViewById<Spinner>(R.id.spinnerFrom)
        val spinnerTo = view.findViewById<Spinner>(R.id.spinnerTo)
        val etAmount = view.findViewById<EditText>(R.id.etAmount)
        val btnConvert = view.findViewById<Button>(R.id.btnConvert)
        val tvResult = view.findViewById<TextView>(R.id.tvCurrencyResult)
        val tvNote = view.findViewById<TextView>(R.id.tvCurrencyNote)

        val currencies = CurrencyApi.commonCurrencies
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, currencies)
        spinnerFrom.adapter = adapter
        spinnerTo.adapter = adapter
        spinnerFrom.setSelection(currencies.indexOf("USD"))
        spinnerTo.setSelection(currencies.indexOf("PKR"))

        btnConvert.setOnClickListener {
            val amountText = etAmount.text.toString()
            val amount = amountText.toDoubleOrNull()
            if (amount == null) {
                Toast.makeText(requireContext(), "Amount daalein", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val from = spinnerFrom.selectedItem as String
            val to = spinnerTo.selectedItem as String

            tvResult.text = "..."
            lifecycleScope.launch {
                try {
                    val rates = if (lastRates != null && lastBase == from) {
                        lastRates!!
                    } else {
                        val fetched = CurrencyApi.fetchRates(from)
                        lastRates = fetched
                        lastBase = from
                        fetched
                    }
                    val rate = rates[to]
                    if (rate == null) {
                        tvResult.text = "N/A"
                    } else {
                        val converted = amount * rate
                        tvResult.text = "%.2f %s".format(converted, to)
                        tvNote.text = "1 $from = %.4f $to (live rate)".format(rate)
                    }
                } catch (e: Exception) {
                    tvResult.text = "Offline"
                    tvNote.text = getString(R.string.rates_offline_note)
                }
            }
        }
    }
}
