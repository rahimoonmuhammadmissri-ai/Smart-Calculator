package com.missrirahimoon.smartcalc.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.missrirahimoon.smartcalc.R
import com.missrirahimoon.smartcalc.util.CurrencyDatabase
import com.missrirahimoon.smartcalc.util.CurrencyRatesRepository
import kotlinx.coroutines.launch

class CurrencyFragment : Fragment(R.layout.fragment_currency) {

    private data class RowViews(
        val root: View,
        val flag: TextView,
        val code: TextView,
        val name: TextView,
        val amount: EditText,
        val selector: View
    )

    private lateinit var rows: List<RowViews>
    private lateinit var tvLastUpdated: TextView
    private var rowCodes = arrayOf("PKR", "USD", "EUR")
    private var rates: Map<String, Double> = emptyMap()
    private var isUpdatingProgrammatically = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rowIds = listOf(R.id.row1, R.id.row2, R.id.row3)
        rows = rowIds.map { rowId ->
            val root = view.findViewById<View>(rowId)
            RowViews(
                root = root,
                flag = root.findViewById(R.id.tvFlag),
                code = root.findViewById(R.id.tvCode),
                name = root.findViewById(R.id.tvName),
                amount = root.findViewById(R.id.etAmount),
                selector = root.findViewById(R.id.rowSelector)
            )
        }
        tvLastUpdated = view.findViewById(R.id.tvLastUpdated)

        rows.forEachIndexed { index, rowViews ->
            bindRowStatic(index)
            rowViews.selector.setOnClickListener {
                val intent = Intent(requireContext(), CurrencyPickerActivity::class.java)
                startActivityForResult(intent, index)
            }
            rowViews.amount.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (isUpdatingProgrammatically) return
                    recalcFrom(index, s?.toString().orEmpty())
                }
            })
        }

        view.findViewById<Button>(R.id.btnRefreshRates).setOnClickListener {
            loadRates(forceNetwork = true)
        }

        loadRates(forceNetwork = false)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode in 0..2) {
            val newCode = data?.getStringExtra(CurrencyPickerActivity.EXTRA_CODE) ?: return
            rowCodes[requestCode] = newCode
            bindRowStatic(requestCode)
            recalcFrom(requestCode, rows[requestCode].amount.text.toString())
        }
    }

    private fun bindRowStatic(index: Int) {
        val entry = CurrencyDatabase.findByCode(rowCodes[index]) ?: return
        val rowViews = rows[index]
        rowViews.flag.text = entry.flagEmoji
        rowViews.code.text = entry.code
        rowViews.name.text = entry.displayName
    }

    private fun loadRates(forceNetwork: Boolean) {
        tvLastUpdated.text = "Updating..."
        viewLifecycleOwner.lifecycleScope.launch {
            val result = CurrencyRatesRepository.getRates(requireContext())
            if (result != null) {
                rates = result
                tvLastUpdated.text = "Last update: ${CurrencyRatesRepository.lastUpdatedLabel(requireContext())}"
                recalcFrom(1, rows[1].amount.text.toString().ifEmpty { "1" })
            } else {
                tvLastUpdated.text = "No internet and no saved rates yet"
            }
        }
    }

    /** Recomputes the other two rows based on the row the user just edited. */
    private fun recalcFrom(editedIndex: Int, rawAmount: String) {
        if (rates.isEmpty()) return
        val amount = rawAmount.toDoubleOrNull() ?: 0.0
        val editedRate = rates[rowCodes[editedIndex]] ?: return

        isUpdatingProgrammatically = true
        rows.forEachIndexed { index, rowViews ->
            if (index == editedIndex) return@forEachIndexed
            val targetRate = rates[rowCodes[index]] ?: return@forEachIndexed
            val converted = amount / editedRate * targetRate
            rowViews.amount.setText(formatAmount(converted))
        }
        isUpdatingProgrammatically = false
    }

    private fun formatAmount(value: Double): String {
        return "%.4f".format(value).trimEnd('0').trimEnd('.')
    }
}
