package com.missrirahimoon.smartcalc.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.missrirahimoon.smartcalc.R
import com.missrirahimoon.smartcalc.util.CurrencyDatabase

class CurrencyPickerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CODE = "extra_code"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_currency_picker)

        findViewById<MaterialToolbar>(R.id.pickerToolbar).setNavigationOnClickListener { finish() }

        val rv = findViewById<RecyclerView>(R.id.rvCurrencies)
        rv.layoutManager = LinearLayoutManager(this)

        val adapter = CurrencyPickerAdapter(CurrencyDatabase.all) { entry ->
            val result = Intent().putExtra(EXTRA_CODE, entry.code)
            setResult(Activity.RESULT_OK, result)
            finish()
        }
        rv.adapter = adapter

        val search = findViewById<EditText>(R.id.etSearch)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }
}
