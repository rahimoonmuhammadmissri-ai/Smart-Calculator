package com.missrirahimoon.smartcalc.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.missrirahimoon.smartcalc.R
import com.missrirahimoon.smartcalc.util.CurrencyEntry

class CurrencyPickerAdapter(
    private val fullList: List<CurrencyEntry>,
    private val onPick: (CurrencyEntry) -> Unit
) : RecyclerView.Adapter<CurrencyPickerAdapter.ViewHolder>() {

    private var shownList: List<CurrencyEntry> = fullList.sortedBy { it.displayName }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flag: TextView = itemView.findViewById(R.id.tvPickFlag)
        val name: TextView = itemView.findViewById(R.id.tvPickName)
        val code: TextView = itemView.findViewById(R.id.tvPickCode)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_currency_pick, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = shownList[position]
        holder.flag.text = entry.flagEmoji
        holder.name.text = entry.displayName
        holder.code.text = entry.code
        holder.itemView.setOnClickListener { onPick(entry) }
    }

    override fun getItemCount(): Int = shownList.size

    fun filter(query: String) {
        val q = query.trim().lowercase()
        shownList = if (q.isEmpty()) {
            fullList.sortedBy { it.displayName }
        } else {
            fullList.filter {
                it.displayName.lowercase().contains(q) || it.code.lowercase().contains(q)
            }.sortedBy { it.displayName }
        }
        notifyDataSetChanged()
    }
}
