package com.missrirahimoon.smartcalc.ui

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.missrirahimoon.smartcalc.R
import com.missrirahimoon.smartcalc.util.UnitConverter

class UnitsFragment : Fragment(R.layout.fragment_units) {

    private val categories = listOf(
        R.string.category_length,
        R.string.category_weight,
        R.string.category_temperature
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spinnerCategory = view.findViewById<Spinner>(R.id.spinnerCategory)
        val spinnerFrom = view.findViewById<Spinner>(R.id.spinnerUnitFrom)
        val spinnerTo = view.findViewById<Spinner>(R.id.spinnerUnitTo)
        val etAmount = view.findViewById<EditText>(R.id.etUnitAmount)
        val btnConvert = view.findViewById<Button>(R.id.btnUnitConvert)
        val tvResult = view.findViewById<TextView>(R.id.tvUnitResult)

        val categoryLabels = categories.map { getString(it) }
        spinnerCategory.adapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_dropdown_item, categoryLabels
        )

        fun unitListFor(position: Int): List<String> = when (position) {
            0 -> UnitConverter.lengthUnits
            1 -> UnitConverter.weightUnits
            else -> UnitConverter.temperatureUnits
        }

        fun refreshUnitSpinners(position: Int) {
            val units = unitListFor(position)
            val unitAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, units)
            spinnerFrom.adapter = unitAdapter
            spinnerTo.adapter = unitAdapter
            if (units.size > 1) spinnerTo.setSelection(1)
            tvResult.text = getString(R.string.result_placeholder)
        }

        spinnerCategory.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, v: View?, position: Int, id: Long) {
                refreshUnitSpinners(position)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        refreshUnitSpinners(0)

        btnConvert.setOnClickListener {
            val amount = etAmount.text.toString().toDoubleOrNull()
            if (amount == null) {
                Toast.makeText(requireContext(), "Amount daalein", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val from = spinnerFrom.selectedItem as String
            val to = spinnerTo.selectedItem as String

            val result = when (spinnerCategory.selectedItemPosition) {
                0 -> UnitConverter.convertLength(amount, from, to)
                1 -> UnitConverter.convertWeight(amount, from, to)
                else -> UnitConverter.convertTemperature(amount, from, to)
            }

            val formattedNumber = "%.4f".format(result).trimEnd('0').trimEnd('.')
            tvResult.text = "$formattedNumber $to"
        }
    }
}
