package com.missrirahimoon.smartcalc.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Fetches live exchange rates from open.er-api.com — a free, no-API-key-required
 * service. Returns a map of currency code -> rate relative to the given base.
 */
object CurrencyApi {

    suspend fun fetchRates(base: String): Map<String, Double> = withContext(Dispatchers.IO) {
        val url = URL("https://open.er-api.com/v6/latest/$base")
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 10000

        try {
            val responseCode = connection.responseCode
            if (responseCode != 200) {
                throw Exception("Server returned $responseCode")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val ratesJson = json.getJSONObject("rates")
            val result = mutableMapOf<String, Double>()
            ratesJson.keys().forEach { key ->
                result[key] = ratesJson.getDouble(key)
            }
            result
        } finally {
            connection.disconnect()
        }
    }

    val commonCurrencies = listOf(
        "USD", "EUR", "GBP", "PKR", "SAR", "AED", "INR", "CNY",
        "JPY", "AUD", "CAD", "CHF", "TRY", "MYR", "SGD", "QAR", "KWD", "BDT"
    )
}
