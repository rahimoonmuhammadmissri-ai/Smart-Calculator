package com.missrirahimoon.smartcalc.util

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Fetches exchange rates (base = USD) from a free, no-key API, and caches the
 * result in SharedPreferences so the converter keeps working offline after
 * the first successful update.
 */
object CurrencyRatesRepository {

    private const val PREFS = "smartcalc_currency_cache"
    private const val KEY_RATES = "rates_json"
    private const val KEY_UPDATED = "rates_updated_at"

    /** Tries to fetch fresh rates from the internet and cache them; falls back
     *  to the last cached rates if offline or the request fails. Returns
     *  null only if there is no internet AND no cache yet. */
    suspend fun getRates(context: Context): Map<String, Double>? = withContext(Dispatchers.IO) {
        try {
            val fresh = fetchFromNetwork()
            saveToCache(context, fresh)
            fresh
        } catch (e: Exception) {
            loadFromCache(context)
        }
    }

    fun lastUpdatedLabel(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val timestamp = prefs.getLong(KEY_UPDATED, -1L)
        if (timestamp < 0) return "Not updated yet"
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        return fmt.format(Date(timestamp))
    }

    private fun fetchFromNetwork(): Map<String, Double> {
        val url = URL("https://open.er-api.com/v6/latest/USD")
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 10000
        connection.readTimeout = 10000
        try {
            if (connection.responseCode != 200) throw Exception("Server returned ${connection.responseCode}")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val ratesJson = json.getJSONObject("rates")
            val result = mutableMapOf<String, Double>()
            ratesJson.keys().forEach { key -> result[key] = ratesJson.getDouble(key) }
            return result
        } finally {
            connection.disconnect()
        }
    }

    private fun saveToCache(context: Context, rates: Map<String, Double>) {
        val json = JSONObject()
        rates.forEach { (code, rate) -> json.put(code, rate) }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_RATES, json.toString())
            .putLong(KEY_UPDATED, System.currentTimeMillis())
            .apply()
    }

    private fun loadFromCache(context: Context): Map<String, Double>? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_RATES, null) ?: return null
        val json = JSONObject(jsonStr)
        val result = mutableMapOf<String, Double>()
        json.keys().forEach { key -> result[key] = json.getDouble(key) }
        return result
    }
}
