package com.missrirahimoon.smartcalc.util

import kotlin.math.*

/**
 * Evaluates a math expression string like "sin(30)+2^3*(4-1)".
 * Supports: + - * / ^ % ( ), sin cos tan log ln sqrt, constants pi e, and factorial (!).
 * Trig functions operate in degrees.
 */
object ExpressionEvaluator {

    class EvaluationException(message: String) : Exception(message)

    fun evaluate(rawInput: String): Double {
        val input = rawInput
            .replace("×", "*")
            .replace("÷", "/")
            .replace("π", "pi")
            .replace(",", "")
            .trim()

        if (input.isEmpty()) throw EvaluationException("Empty expression")

        val tokens = tokenize(input)
        val rpn = toRpn(tokens)
        return evalRpn(rpn)
    }

    private sealed class Token
    private data class Num(val value: Double) : Token()
    private data class Op(val symbol: String) : Token()
    private data class Func(val name: String) : Token()
    private object LParen : Token()
    private object RParen : Token()

    private val functionNames = setOf("sin", "cos", "tan", "log", "ln", "sqrt")

    private fun tokenize(input: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        while (i < input.length) {
            val c = input[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || c == '.' -> {
                    val start = i
                    while (i < input.length && (input[i].isDigit() || input[i] == '.')) i++
                    tokens.add(Num(input.substring(start, i).toDouble()))
                }
                c.isLetter() -> {
                    val start = i
                    while (i < input.length && input[i].isLetter()) i++
                    val word = input.substring(start, i)
                    when (word) {
                        "pi" -> tokens.add(Num(Math.PI))
                        "e" -> tokens.add(Num(Math.E))
                        in functionNames -> tokens.add(Func(word))
                        else -> throw EvaluationException("Unknown token: $word")
                    }
                }
                c == '(' -> { tokens.add(LParen); i++ }
                c == ')' -> { tokens.add(RParen); i++ }
                c == '!' -> { tokens.add(Op("!")); i++ }
                c in "+-*/^%" -> {
                    // handle unary minus: if previous token is null, an operator, or '(' treat '-' as unary
                    if (c == '-' && (tokens.isEmpty() || tokens.last() is Op || tokens.last() is LParen || tokens.last() is Func)) {
                        val start = i + 1
                        var j = start
                        while (j < input.length && (input[j].isDigit() || input[j] == '.')) j++
                        if (j > start) {
                            tokens.add(Num(-input.substring(start, j).toDouble()))
                            i = j
                        } else {
                            tokens.add(Op("u-"))
                            i++
                        }
                    } else {
                        tokens.add(Op(c.toString()))
                        i++
                    }
                }
                else -> throw EvaluationException("Unexpected character: $c")
            }
        }
        return tokens
    }

    private fun precedence(op: String): Int = when (op) {
        "+", "-" -> 1
        "*", "/", "%" -> 2
        "u-" -> 3
        "^" -> 4
        "!" -> 5
        else -> 0
    }

    private fun isRightAssoc(op: String) = op == "^" || op == "u-"

    private fun toRpn(tokens: List<Token>): List<Token> {
        val output = mutableListOf<Token>()
        val stack = ArrayDeque<Token>()

        for (token in tokens) {
            when (token) {
                is Num -> output.add(token)
                is Func -> stack.addLast(token)
                is Op -> {
                    while (stack.isNotEmpty() && stack.last() is Op &&
                        ((precedence((stack.last() as Op).symbol) > precedence(token.symbol)) ||
                                (precedence((stack.last() as Op).symbol) == precedence(token.symbol) && !isRightAssoc(token.symbol)))
                    ) {
                        output.add(stack.removeLast())
                    }
                    stack.addLast(token)
                }
                LParen -> stack.addLast(token)
                RParen -> {
                    while (stack.isNotEmpty() && stack.last() != LParen) {
                        output.add(stack.removeLast())
                    }
                    if (stack.isEmpty()) throw EvaluationException("Mismatched parentheses")
                    stack.removeLast() // pop LParen
                    if (stack.isNotEmpty() && stack.last() is Func) {
                        output.add(stack.removeLast())
                    }
                }
            }
        }
        while (stack.isNotEmpty()) {
            val t = stack.removeLast()
            if (t == LParen || t == RParen) throw EvaluationException("Mismatched parentheses")
            output.add(t)
        }
        return output
    }

    private fun evalRpn(rpn: List<Token>): Double {
        val stack = ArrayDeque<Double>()
        for (token in rpn) {
            when (token) {
                is Num -> stack.addLast(token.value)
                is Func -> {
                    val a = stack.removeLastOrNull() ?: throw EvaluationException("Invalid expression")
                    stack.addLast(applyFunc(token.name, a))
                }
                is Op -> {
                    if (token.symbol == "u-") {
                        val a = stack.removeLastOrNull() ?: throw EvaluationException("Invalid expression")
                        stack.addLast(-a)
                    } else if (token.symbol == "!") {
                        val a = stack.removeLastOrNull() ?: throw EvaluationException("Invalid expression")
                        stack.addLast(factorial(a))
                    } else {
                        val b = stack.removeLastOrNull() ?: throw EvaluationException("Invalid expression")
                        val a = stack.removeLastOrNull() ?: throw EvaluationException("Invalid expression")
                        stack.addLast(applyOp(token.symbol, a, b))
                    }
                }
                else -> throw EvaluationException("Invalid token in RPN")
            }
        }
        if (stack.size != 1) throw EvaluationException("Invalid expression")
        return stack.last()
    }

    private fun applyOp(op: String, a: Double, b: Double): Double = when (op) {
        "+" -> a + b
        "-" -> a - b
        "*" -> a * b
        "/" -> if (b == 0.0) throw EvaluationException("Divide by zero") else a / b
        "^" -> a.pow(b)
        "%" -> a % b
        else -> throw EvaluationException("Unknown operator: $op")
    }

    private fun applyFunc(name: String, a: Double): Double = when (name) {
        "sin" -> sin(Math.toRadians(a))
        "cos" -> cos(Math.toRadians(a))
        "tan" -> tan(Math.toRadians(a))
        "log" -> log10(a)
        "ln" -> ln(a)
        "sqrt" -> sqrt(a)
        else -> throw EvaluationException("Unknown function: $name")
    }

    private fun factorial(a: Double): Double {
        if (a < 0 || a != floor(a)) throw EvaluationException("Factorial needs a non-negative whole number")
        var result = 1.0
        var n = a.toInt()
        while (n > 1) { result *= n; n-- }
        return result
    }
}
