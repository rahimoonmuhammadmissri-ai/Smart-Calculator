package com.missrirahimoon.smartcalc.util

object UnitConverter {

    enum class Category { LENGTH, WEIGHT, TEMPERATURE }

    val lengthUnits = listOf("Meter", "Kilometer", "Centimeter", "Mile", "Feet", "Inch")
    val weightUnits = listOf("Kilogram", "Gram", "Pound", "Ounce")
    val temperatureUnits = listOf("Celsius", "Fahrenheit", "Kelvin")

    // All length units converted to meters as the base unit
    private val lengthToMeters = mapOf(
        "Meter" to 1.0,
        "Kilometer" to 1000.0,
        "Centimeter" to 0.01,
        "Mile" to 1609.344,
        "Feet" to 0.3048,
        "Inch" to 0.0254
    )

    // All weight units converted to kilograms as the base unit
    private val weightToKg = mapOf(
        "Kilogram" to 1.0,
        "Gram" to 0.001,
        "Pound" to 0.453592,
        "Ounce" to 0.0283495
    )

    fun convertLength(value: Double, from: String, to: String): Double {
        val meters = value * (lengthToMeters[from] ?: 1.0)
        return meters / (lengthToMeters[to] ?: 1.0)
    }

    fun convertWeight(value: Double, from: String, to: String): Double {
        val kg = value * (weightToKg[from] ?: 1.0)
        return kg / (weightToKg[to] ?: 1.0)
    }

    fun convertTemperature(value: Double, from: String, to: String): Double {
        // Convert to Celsius first
        val celsius = when (from) {
            "Celsius" -> value
            "Fahrenheit" -> (value - 32) * 5 / 9
            "Kelvin" -> value - 273.15
            else -> value
        }
        return when (to) {
            "Celsius" -> celsius
            "Fahrenheit" -> celsius * 9 / 5 + 32
            "Kelvin" -> celsius + 273.15
            else -> celsius
        }
    }
}
